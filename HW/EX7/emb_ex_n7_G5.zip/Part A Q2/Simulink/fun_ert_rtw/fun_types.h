//
// File: fun_types.h
//
// Code generated for Simulink model 'fun'.
//
// Model version                  : 1.8
// Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
// C/C++ source code generated on : Sat Jan  4 11:43:38 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_fun_types_h_
#define RTW_HEADER_fun_types_h_

// Forward declaration for rtModel
typedef struct tag_RTM_fun_T RT_MODEL_fun_T;

#endif                                 // RTW_HEADER_fun_types_h_

//
// File trailer for generated code.
//
// [EOF]
//
